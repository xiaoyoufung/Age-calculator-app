const iconArrow = document.getElementById('icon-arrow');

iconArrow.addEventListener('click', (e) => {
    alert("submit form");
})